# Chrome Bookmarks to Reference List Extension
A chrome extension that coverts any selected bookmarks folder to a list of references. Perfect for the lazy college student submitting an assignment :)

I've got a small tutorial on how to build Chrome plugins [here](https://devrohan.wordpress.com/2015/02/21/building-a-chrome-extension/)
